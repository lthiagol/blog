---
layout: project
title: Projects
permalink: /projects/
---

Few of my projects. Currently doing more in backend, focused in Python and Django.
